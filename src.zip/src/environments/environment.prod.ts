export const environment = {
  production: true,
    firebase: {
      apiKey: 'AIzaSyDskMCKrlFDx5XSgnrVCCmJu2GqHFVJqxo',
      authDomain: 'airline-checkin-24383.firebaseapp.com',
      databaseURL: 'https://airline-checkin-24383.firebaseio.com',
      projectId: 'airline-checkin-24383',
      storageBucket: 'airline-checkin-24383.appspot.com',
      messagingSenderId: '490591841438',
      appId: '1:490591841438:web:ab94e8bc9fb07807b0df8f',
      measurementId: 'G-ZZ4DT82BX7',
      backendAPI: 'https://airline-management-apis.herokuapp.com'
    }
};
