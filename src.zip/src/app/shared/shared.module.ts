import { NgModule } from '@angular/core';


import {MatExpansionModule} from '@angular/material/expansion'
import { MatToolbarModule} from '@angular/material/toolbar'
import { MatButtonModule} from '@angular/material/button'
import { MatAutocompleteModule} from '@angular/material/autocomplete'
import { MatFormFieldModule} from '@angular/material/form-field'
import { MatInputModule} from '@angular/material/input'
import { MatSelectModule} from '@angular/material/select'
import { MatDialogModule,MAT_DIALOG_DEFAULT_OPTIONS} from '@angular/material/dialog'
import { MatDividerModule} from '@angular/material/divider'
import { MatSlideToggleModule} from '@angular/material/slide-toggle'
import { MatTableModule} from '@angular/material/table'
import { MatCheckboxModule} from '@angular/material/checkbox'
import { MatRadioModule} from '@angular/material/radio'
import { MatChipsModule} from '@angular/material/chips'
import { MatTabsModule} from '@angular/material/tabs'
import { MatDatepickerModule} from '@angular/material/datepicker'
import {  MatNativeDateModule,MatRippleModule
} from '@angular/material/core'

import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PassengerDetailComponent } from './components/modal/passenger-detail/passenger-detail.component';
import { PassengerListComponent } from './passenger-list/passenger-list.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SeatmapComponent } from './components/seatmap/seatmap.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { PassengersTableComponent } from './components/passengers-table/passengers.table.component';
import { InflightpassengerDetailComponent } from './components/modal/in-flight-passenger-detail/in-flight-passenger-detail.component';
import { ChipListComponent } from './components/chip-list/chip-list.component';
import { NewPassengerComponent } from './components/modal/new-passenger/new-passenger.component';
import { YesNoPipe } from './pipes/yes-no.pipe';

@NgModule({
  declarations: [
    PassengerDetailComponent,
    InflightpassengerDetailComponent,
    NewPassengerComponent,
    PassengerListComponent,
    HeaderComponent,
    FooterComponent,
    SeatmapComponent,
    PassengersTableComponent,
    ChipListComponent,
    YesNoPipe,
  ],
  imports: [
    CommonModule,
    MatToolbarModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatSelectModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    RouterModule,
    MatTableModule,
    MatIconModule,
    MatCheckboxModule,
    MatRadioModule,
    MatChipsModule,
    MatTabsModule,
    MatDatepickerModule,
  ],
  exports: [
    PassengerDetailComponent,
    PassengerListComponent,
    HeaderComponent,
    FooterComponent,
    SeatmapComponent,
    PassengersTableComponent,
    ChipListComponent,
    MatToolbarModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRippleModule,
    MatSelectModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatSlideToggleModule,
    MatTableModule,
    MatIconModule,
    MatCheckboxModule,
    MatRadioModule,
    MatChipsModule,
    MatTabsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    YesNoPipe,
  ],
  entryComponents: [
    PassengerDetailComponent,
    InflightpassengerDetailComponent,
    NewPassengerComponent,
    SeatmapComponent,
    PassengersTableComponent,
    ChipListComponent,
  ],
  providers: [
    {
      provide: MAT_DIALOG_DEFAULT_OPTIONS,
      useValue: { hasBackdrop: true, direction: 'ltr' },
    },
  ],
})
export class SharedModule {}
