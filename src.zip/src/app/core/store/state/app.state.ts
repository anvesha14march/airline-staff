import { RouterReducerState } from '@ngrx/router-store';

export interface IAppState {
  appData: {};
}
export const initialAppData = {
};
